package com.amaz1n.adheroes2;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

import java.util.ArrayList;
import java.util.Random;

public class AdGame extends ApplicationAdapter {

	enum Screen {
		INSTRUCTIONS,SELECT, GAME, END;
	}

	Screen currentScreen = Screen.SELECT;

	SpriteBatch batch;
	ShapeRenderer sr;

	//1024x800

	Sprite spr1;
	Sprite spr2;
	player p1;
	player p2;
	Texture instructions ,map, menuBack, playerBanner, spacePlay, spaceReturn;
	Texture disruption,approachLock,escapeLock;
	Texture slimeSelect1, slimeSelect2, binSelect1, binSelect2, robotSelect1, robotSelect2, mcManSelect1, mcManSelect2, catSelect1, catSelect2;

	float INCG,MAXG;

	int LEFT,FORWARD,RIGHT;
	int STAGELEFT,STAGERIGHT;
	int GROUND;
	int IDLE,SHOOT,MELEE,WALK,JUMP;
	int p1Select, p2Select;
	String p1Char, p2Char;
	Boolean p1Ready, p2Ready;

	boolean gameRunning;

	ArrayList<String> chars = new ArrayList<String>();
	ArrayList<String> mapList = new ArrayList<String>();

	@Override
	public void create () {
		INCG = 0.3f;MAXG = -7.5f;//increment 0.3 is 1/25th of maximum 7.5

		LEFT = 0;FORWARD = 1;RIGHT = 2;
		STAGELEFT = 200;STAGERIGHT = 696;//equal distance
		GROUND = 100;
		IDLE = 0;SHOOT = 1;MELEE = 2;WALK = 3;JUMP = 9;
		batch = new SpriteBatch();
		sr = new ShapeRenderer();
		p1Select = 0; p2Select = 0;
		p1Ready = false; p2Ready = false;

		instructions = new Texture("Instructions.png");
		map = new Texture("map_slimeFields.png");
		spaceReturn = new Texture("space2return.png");
		spacePlay = new Texture("space2play.png");
		playerBanner = new Texture("playerBanner.png");
		menuBack = new Texture("start_screen.png");
		disruption = new Texture("stunOverlay.png");
		approachLock = new Texture("Approach_Locked.png");
		escapeLock = new Texture("Escape_Locked.png");

		slimeSelect1 = new Texture("slime1_IF.png");
		slimeSelect2 = new Texture("slime2_IF.png");
		binSelect1 = new Texture("bin1_IF.png");
		binSelect2 = new Texture("bin2_IF.png");
		robotSelect1 = new Texture("robot1_IF.png");
		robotSelect2 = new Texture("robot2_IF.png");
		mcManSelect1 = new Texture("mcMan1_IF.png");
		mcManSelect2 = new Texture("mcMan2_IF.png");
		catSelect1 = new Texture("cat1_IF.png");
		catSelect2 = new Texture("cat2_IF.png");

		gameRunning = false;//start game

		chars.add("slime");
		chars.add("bin");
		chars.add("robot");
		chars.add("mcMan");
		chars.add("cat");
	}

	public Texture[][] charFrames(String s){//load frames for each character
		Texture l0 = new Texture(s+"_IL.png");
		Texture l1 = new Texture(s+"_ShootL.png");
		Texture l2 = new Texture(s+"_MeleeL.png");
		Texture l3 = new Texture(s+"_WL_1.png");
		Texture l4 = new Texture(s+"_WL_2.png");
		Texture l5 = new Texture(s+"_WL_3.png");
		Texture l6 = new Texture(s+"_WL_4.png");
		Texture l7 = new Texture(s+"_WL_5.png");
		Texture l8 = new Texture(s+"_WL_6.png");
		Texture l9 = new Texture(s+"_JL_1.png");
		Texture l10 = new Texture(s+"_JL_2.png");
		Texture[] lFrames = new Texture[]{l0,l1,l2,l3,l4,l5,l6,l7,l8,l9,l10};
		Texture f0 = new Texture(s+"_IF.png");////Only one frame
		Texture[] fFrames = new Texture[]{f0};///////////////front-facing
		Texture r0 = new Texture(s+"_IR.png");
		Texture r1 = new Texture(s+"_ShootR.png");
		Texture r2 = new Texture(s+"_MeleeR.png");
		Texture r3 = new Texture(s+"_WR_1.png");
		Texture r4 = new Texture(s+"_WR_2.png");
		Texture r5 = new Texture(s+"_WR_3.png");
		Texture r6 = new Texture(s+"_WR_4.png");
		Texture r7 = new Texture(s+"_WR_5.png");
		Texture r8 = new Texture(s+"_WR_6.png");
		Texture r9 = new Texture(s+"_JR_1.png");
		Texture r10 = new Texture(s+"_JR_2.png");
		Texture[] rFrames = new Texture[]{r0,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10};

		return new Texture[][]{lFrames,fFrames,rFrames};//return 2D array
	}

	public void movement(player p){//falling, borders, ground, etc.
		//Vertical limits
		if(p.getY()<=GROUND){//on or below ground
			p.setY(GROUND);//confirm ground level
			p.setFalling(false);}
		else{             //not on the ground
			p.setFalling(true);}

		if(!p.getFalling()){//if falling is false
			p.setVY(0);}
		else{               //if falling is true
			if(p.getVY()>=MAXG){//travelling up or not at full gravity
				p.changeVY(-INCG);//subtract an increment
			}
			else{//reached or surpassed max gravity
				p.setVY(MAXG);//confirm max gravity
			}
		}
		//Horizontal limits
		if(p.getX()<=-25){//differing texture borders, some sprites may clip into the walls
			p.setX(-25);}
		if(p.getX()>=920){//1024-0.75(128)-8
			p.setX(920);}

		//check horizontal movement
		if(p.getVX()<0){//moving left
			p.setDirection(LEFT);
		}
		if(p.getVX()>0){//moving right
			p.setDirection(RIGHT);
		}

		//set horizontal walk frames
		if(p.getVX()!=0){
			p.setFrameCount();
			if(p.getDirection()==LEFT){//moving left
				p.setCurrentFrame(LEFT,WALK+p.getFrameCount()/6 %6);
			}
			if(p.getDirection()==RIGHT){
				p.setCurrentFrame(RIGHT,WALK+p.getFrameCount()/6 %6);
			}
		}

		//check vertical movement
		if(p.getDirection()==FORWARD){
			if(p.getStageDefault()==STAGELEFT){
				p.setDirection(RIGHT);
			}
			if(p.getStageDefault()==STAGERIGHT){
				p.setDirection(LEFT);
			}
		}

		if(p.getVY()>0){
			if(p.getDirection()==RIGHT){
				p.setCurrentFrame(RIGHT,JUMP);
			}
			if(p.getDirection()==LEFT && p.getVY()>0){
				p.setCurrentFrame(LEFT,JUMP);
			}
		}
		else if(p.getVY()<0){
			if(p.getDirection()==RIGHT){
				p.setCurrentFrame(RIGHT,JUMP+1);
			}
			if(p.getDirection()==LEFT){
				p.setCurrentFrame(LEFT,JUMP+1);
			}
		}

		p.changeX(p.getVX());//move player
		p.changeY(p.getVY());
	}

	public void moveBullets(player p,player opp){
		ArrayList<Bullet> deadBullets = new ArrayList<>();
		for(Bullet b:p.getBullets()){
			if(b.getX()>1024 || b.getX()<0 || b.getY()<0){//out of bounds
				deadBullets.add(b);
			}
			else if(opp.bulletOverlap(b)){//hits opponent
				opp.takeDMG(p.getDMG());
				deadBullets.add(b);
				System.out.println(opp.getName()+opp.getHP());
			}
			else{
				batch.draw(b.getTexture(),b.getX(),b.getY());
				b.changeX();
				b.changeY();
				b.changeVY();
			}
		}
		p.getBullets().removeAll(deadBullets);
	}

	public void controlP(player p,player opp){
		if(p.getFireCount()<0){//can't fire
			p.canFire();//only calling this for the fireCount++;
			batch.draw(disruption,p.getX()+15,p.getY()+15);
		}

		if(p.getY()==GROUND){//touch ground
			p.set2Jump(true);//reset double jump
		}

		if(Gdx.input.isKeyPressed(p.getKey("left")) && Gdx.input.isKeyPressed(p.getKey("right"))){//both directions
			p.setVX(0);
			p.setCurrentFrame(FORWARD,IDLE);
		}
		else{
			if(Gdx.input.isKeyPressed(p.getKey("left"))){
				//System.out.println(p.getName()+": I SHOULD BE MOVING LEFT");
				if(Gdx.input.isKeyPressed(p.getKey("down")) && !Gdx.input.isKeyPressed(p.getKey("up")) && p.getY()>GROUND){
					p.setVX(-9);}//feature: horizontal movement during fastfall is increased.
				else{
					p.setVX(-3);}
			}
			if(Gdx.input.isKeyPressed(p.getKey("right"))){
				if(Gdx.input.isKeyPressed(p.getKey("down")) && !Gdx.input.isKeyPressed(p.getKey("up")) && p.getY()>GROUND){
					p.setVX(9);}
				else{
					p.setVX(3);}
			}
		}

		//no key input and on the ground
		if(!Gdx.input.isKeyPressed(p.getKey("left")) && !Gdx.input.isKeyPressed(p.getKey("right")) && p.getY()==GROUND){
			p.setVX(0);
			p.setCurrentFrame(p.getDirection(),IDLE);//reset to idle
		}

		if(p.getY()>GROUND){//in the air
			if(Gdx.input.isKeyPressed(p.getKey("down")) && !Gdx.input.isKeyPressed(p.getKey("up"))){//down button held
				p.setVY(-10);
				p.setCurrentFrame(FORWARD,IDLE);//pressing down sets character to fwd idle
				p.changeY(p.getVY());
			}
		}

		if(p.getDirection()!=FORWARD){//direction causes errors
			if(Gdx.input.isKeyPressed(p.getKey("up")) && p.getY()==GROUND && !Gdx.input.isKeyPressed(p.getKey("down"))){
				//jump from ground
				//can be held to instantly jump when reset. Does not attempt to jump when down is being held
				p.setVY(9);//not an overwhelming jump as it was before
				p.setCurrentFrame(p.getDirection(),JUMP);
				p.changeY(p.getVY());
			}
			if(Gdx.input.isKeyPressed(p.getKey("up")) && p.get2Jump() && p.getVY()<0){//jump in air
				//double jump only works when falling
				p.setVY(14);//stronger second jump
				p.changeY(p.getVY());
				p.set2Jump(false);
			}
			if(Gdx.input.isKeyPressed(p.getKey("shoot"))){
				p.setCurrentFrame(p.getDirection(),SHOOT);
				if(p.canFire()){//timer says player can shoot
					Bullet b = new Bullet(p.getBulletTexture(),p.getX()+48,p.getY()+48,p.getDirection(),p.getRate());
					p.addBullet(b);
					//System.out.println(p.getBullets().size());
				}
			}
			if(Gdx.input.isKeyPressed(p.getKey("melee"))){
				p.pauseFire();	 	 	 //Making too many methods but isKeyJustPressed didn't display the frame
				if(p.playerOverlap(opp)){//long enough, but I also didn't want the player to shoot while meleeing
					opp.disableFire();
					if(Gdx.input.isKeyJustPressed(p.getKey("melee"))){//button can be held but damage dealt once
						opp.takeDMG(5);//flat 5 damage (skews ttk depending on character, as not factor of 24)
					}
				}
				p.setCurrentFrame(p.getDirection(),MELEE);
			}
		}
	}

	public void selectToGame() {
		if(currentScreen == Screen.SELECT) {
			if(Gdx.input.isKeyPressed(Input.Keys.SPACE)) {
				currentScreen = Screen.GAME;
				gameRunning = true;
			}
		}
		else {
			if(currentScreen == Screen.GAME) {
				if(Gdx.input.isKeyPressed(Input.Keys.SPACE)) {
					currentScreen = Screen.SELECT;
				}
			}
		}
	}

	public void restart() {
		if(currentScreen == Screen.GAME) {
			if(Gdx.input.isKeyPressed(Input.Keys.SPACE)) {
				currentScreen = Screen.SELECT;
			}
		}
	}



	public void selection() {
		if(currentScreen == Screen.SELECT) {
			if(p1Ready == false) {
				if(Gdx.input.isKeyJustPressed(Keys.A)) { //p1 selection
					p1Select-=1;
					if(p1Select < 0) {
						p1Select = chars.size()-1;
					}
					System.out.println("Player 1 picked "+ chars.get(p1Select));
				}
				if(Gdx.input.isKeyJustPressed(Keys.D)) {
					p1Select+=1;
					if(p1Select > chars.size()-1) {
						p1Select = 0;
					}
					System.out.println("Player 1 picked "+ chars.get(p1Select));
				}
			}

			if(p2Ready == false) {
				if(Gdx.input.isKeyJustPressed(Keys.LEFT)) { //p2 selection
					p2Select-=1;
					if(p2Select < 0) {
						p2Select = chars.size()-1;
					}
					System.out.println("Player 2 picked "+ chars.get(p2Select));
				}
				if(Gdx.input.isKeyJustPressed(Keys.RIGHT)) {
					p2Select+=1;
					if(p2Select > chars.size()-1) {
						p2Select = 0;
					}
					System.out.println("Player 2 picked "+ chars.get(p2Select));
				}
			}

			if(Gdx.input.isKeyJustPressed(Keys.C)) {
				p1Ready = true;
				p1Char = chars.get(p1Select);
				System.out.println("Player 1 selected "+ chars.get(p1Select));
				if(p1Char == "slime") {
					Texture[][] slimeFrames = charFrames("slime1");
					Texture slimeBullet = new Texture("slime_Bullet.png");
					Texture slimeWin = new Texture("slime1_Victory.png");
					Texture slimeLoss = new Texture("slime1_Loss.png");
					Texture[] slimeEnd = new Texture[]{slimeWin,slimeLoss};
					p1 = new player("Player 1: ",STAGELEFT,4,4,slimeFrames,slimeBullet,slimeEnd);
					spr1 = new Sprite(p1.getCurrentFrame());
					spr1.setPosition(p1.getX(),p1.getY());
					spr1.setScale(0.75f);
				}
				if(p1Char == "bin") {
					Texture[][] binFrames = charFrames("bin1");
					Texture binBullet = new Texture("bin_Bullet.png");
					Texture binWin = new Texture("bin1_Victory.png");
					Texture binLoss = new Texture("bin1_Loss.png");
					Texture[] binEnd = new Texture[]{binWin,binLoss};
					p1 = new player("Player 1: ",STAGELEFT,8,8,binFrames,binBullet,binEnd);
					spr1 = new Sprite(p1.getCurrentFrame());
					spr1.setPosition(p1.getX(),p1.getY());
					spr1.setScale(0.75f);
				}
				if(p1Char == "robot") {
					Texture[][] robotFrames = charFrames("robot1");
					Texture robotBullet = new Texture("robot_Bullet.png");
					Texture robotWin = new Texture("robot1_Victory.png");
					Texture robotLoss = new Texture("robot1_Loss.png");
					Texture[] robotEnd = new Texture[]{robotWin,robotLoss};
					p1 = new player("Player 1",STAGELEFT,24,24,robotFrames,robotBullet,robotEnd);
					spr1 = new Sprite(p1.getCurrentFrame());
					spr1.setPosition(p1.getX(),p1.getY());
					spr1.setScale(0.75f);
				}
				if(p1Char == "mcMan") {
					Texture[][] mcManFrames = charFrames("mcMan1");
					Texture mcManBullet = new Texture("mcMan_Bullet.png");
					Texture mcManWin = new Texture("mcMan1_Victory.png");
					Texture mcManLoss = new Texture("mcMan1_Loss.png");
					Texture[] mcManEnd = new Texture[]{mcManWin,mcManLoss};
					p1 = new player("Player 1",STAGELEFT,12,12,mcManFrames,mcManBullet,mcManEnd);
					spr1 = new Sprite(p1.getCurrentFrame());
					spr1.setPosition(p1.getX(),p1.getY());
					spr1.setScale(0.75f);
				}
				if(p1Char == "cat") {
					Texture[][] catFrames = charFrames("cat1");
					Texture catBullet = new Texture("cat_Bullet.png");
					Texture catWin = new Texture("cat1_Victory.png");
					Texture catLoss = new Texture("cat1_Loss.png");
					Texture[] catEnd = new Texture[]{catWin,catLoss};
					p1 = new player("Player 1",STAGELEFT,16,16,catFrames,catBullet,catEnd);
					spr1 = new Sprite(p1.getCurrentFrame());
					spr1.setPosition(p1.getX(),p1.getY());
					spr1.setScale(0.75f);
				}

			}

			if(Gdx.input.isKeyJustPressed(Keys.RIGHT_BRACKET)) {
				p2Ready = true;
				p2Char = chars.get(p2Select);
				System.out.println("Player 2 selected "+ chars.get(p2Select));
				if(p2Char == "slime") {
					Texture[][] slimeFrames = charFrames("slime2");
					Texture slimeBullet = new Texture("slime_Bullet.png");
					Texture slimeWin = new Texture("slime2_Victory.png");
					Texture slimeLoss = new Texture("slime2_Loss.png");
					Texture[] slimeEnd = new Texture[]{slimeWin,slimeLoss};
					p2 = new player("Player 2: ",STAGERIGHT,4,4,slimeFrames,slimeBullet,slimeEnd);
					spr2 = new Sprite(p2.getCurrentFrame());
					spr2.setPosition(p2.getX(),p2.getY());
					spr2.setScale(0.75f);
				}
				if(p2Char == "bin") {
					Texture[][] binFrames = charFrames("bin2");
					Texture binBullet = new Texture("bin_Bullet.png");
					Texture binWin = new Texture("bin2_Victory.png");
					Texture binLoss = new Texture("bin2_Loss.png");
					Texture[] binEnd = new Texture[]{binWin,binLoss};
					p2 = new player("Player 2: ",STAGERIGHT,8,8,binFrames,binBullet,binEnd);
					spr2 = new Sprite(p2.getCurrentFrame());
					spr2.setPosition(p2.getX(),p2.getY());
					spr2.setScale(0.75f);
				}
				if(p2Char == "robot") {
					Texture[][] slimeFrames = charFrames("robot2");
					Texture slimeBullet = new Texture("robot_Bullet.png");
					Texture slimeWin = new Texture("robot2_Victory.png");
					Texture slimeLoss = new Texture("robot2_Loss.png");
					Texture[] slimeEnd = new Texture[]{slimeWin,slimeLoss};
					p2 = new player("Player 2",STAGERIGHT,24,24,slimeFrames,slimeBullet,slimeEnd);
					spr2 = new Sprite(p2.getCurrentFrame());
					spr2.setPosition(p2.getX(),p2.getY());
					spr2.setScale(0.75f);
				}
				if(p2Char == "mcMan") {
					Texture[][] mcManFrames = charFrames("mcMan2");
					Texture mcManBullet = new Texture("mcMan_Bullet.png");
					Texture mcManWin = new Texture("mcMan2_Victory.png");
					Texture mcManLoss = new Texture("mcMan2_Loss.png");
					Texture[] mcManEnd = new Texture[]{mcManWin,mcManLoss};
					p2 = new player("Player 2",STAGERIGHT,12,12,mcManFrames,mcManBullet,mcManEnd);
					spr2 = new Sprite(p2.getCurrentFrame());
					spr2.setPosition(p2.getX(),p2.getY());
					spr2.setScale(0.75f);
				}
				if(p2Char == "cat") {
					Texture[][] catFrames = charFrames("cat2");
					Texture catBullet = new Texture("cat_Bullet.png");
					Texture catWin = new Texture("cat2_Victory.png");
					Texture catLoss = new Texture("cat2_Loss.png");
					Texture[] catEnd = new Texture[]{catWin,catLoss};
					p2 = new player("Player 2",STAGERIGHT,16,16,catFrames,catBullet,catEnd);
					spr2 = new Sprite(p2.getCurrentFrame());
					spr2.setPosition(p2.getX(),p2.getY());
					spr2.setScale(0.75f);
				}
			}
		}
	}

	@Override
	public void render () {
		if(currentScreen == Screen.INSTRUCTIONS) {
			batch.begin();

			batch.draw(instructions,0,0);

			batch.end();
		}

		else if(currentScreen == Screen.SELECT) {
			Gdx.gl.glClearColor(0, .25f, 0, 1);
			Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
			batch.begin();

			batch.draw(menuBack,0,0);
			batch.draw(playerBanner,0,420);
			batch.draw(spacePlay,264,200);
			selection();
			selectToGame();

			if(p1Select == 0 || p2Select == 0) { //display current character
				if(p1Select == 0) {
					batch.draw(slimeSelect1,40,300);
				}
				if(p2Select == 0) {
					batch.draw(slimeSelect2,854,300);
				}
			}
			if(p1Select == 1 || p2Select == 1) {
				if(p1Select == 1) {
					batch.draw(binSelect1,40,300);
				}
				if(p2Select == 1) {
					batch.draw(binSelect2,854,300);
				}
			}
			if(p1Select == 2 || p2Select == 2) {
				if(p1Select == 2) {
					batch.draw(robotSelect1,40,300);
				}
				if(p2Select == 2) {
					batch.draw(robotSelect2,854,300);
				}
			}
			if(p1Select == 3 || p2Select == 3) {
				if(p1Select == 3) {
					batch.draw(mcManSelect1,40,300);
				}
				if(p2Select == 3) {
					batch.draw(mcManSelect2,854,300);
				}
			}
			if(p1Select == 4 || p2Select == 4) {
				if(p1Select == 4) {
					batch.draw(catSelect1,40,300);
				}
				if(p2Select == 4) {
					batch.draw(catSelect2,854,300);
				}
			}

			batch.end();
		}

		else if(currentScreen == Screen.GAME) {
			Gdx.gl.glClearColor(1, 0, 0, 1);
			Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
			batch.begin();
			batch.draw(map,0,0);//map is still drawn if round ends

			if(gameRunning){
				controlP(p1,p2);
				spr1.setTexture(p1.getCurrentFrame());
				spr1.draw(batch);
				movement(p1);
				moveBullets(p1,p2);
				spr1.setPosition(p1.getX(),p1.getY());

				controlP(p2,p1);
				spr2.setTexture(p2.getCurrentFrame());
				spr2.draw(batch);
				movement(p2);
				moveBullets(p2,p1);
				spr2.setPosition(p2.getX(),p2.getY());

				sr.begin(ShapeType.Filled);
				sr.setColor(Color.BLUE);//		    512/480  (half the screen length divided by max HP)
				sr.rect(0,780,p1.getHP()*16/15f,20);
				sr.setColor(Color.RED);
				sr.rect(512,780,p2.getHP()*16/15f,20);
			}

			if(p1.getHP()<=0 && p2.getHP()<=0){//unlikely case where both lose
				gameRunning = false;
				batch.draw(p1.getLoss(),p1.getStageDefault(),GROUND);
				batch.draw(p2.getLoss(),p2.getStageDefault(),GROUND);
				switchScreens();
			}
			else if(p1.getHP()<=0){//p1 wins
				gameRunning = false;
				batch.draw(p1.getLoss(),p1.getStageDefault(),GROUND);
				batch.draw(p2.getWin(),384,0);
				switchScreens();
			}
			else if(p2.getHP()<=0){//p2 wins
				gameRunning = false;
				batch.draw(p1.getWin(),384,0);
				batch.draw(p2.getLoss(),p2.getStageDefault(),GROUND);
				switchScreens();
			}

			batch.end();
			sr.end();
		}
	}

	@Override
	public void dispose () {
		batch.dispose();
	}
}

/*
slime:         FR 4, DMG 4
recycle bin:   FR 8, DMG 8
fast food man: FR12, DMG12
witch cat:     FR16, DMG16
dumbbell rack: FR20, DMG20
robot:         FR24, DMG24
*/


