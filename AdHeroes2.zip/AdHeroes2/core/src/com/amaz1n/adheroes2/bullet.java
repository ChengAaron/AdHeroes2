package com.amaz1n.adheroes2;

import com.badlogic.gdx.graphics.Texture;
//20x20
class Bullet {
    private int x,y;
    private int vx;
    private float vy;
    private float gravInc;
    private Texture bull;

    public Bullet(Texture t,int playerX,int playerY,int direction,int rate){
        x = playerX;
        y = playerY;
        if(direction==0){//Left
            vx = -9;
        }
        else{//Right
            vx = 9;
        }
        vy = 0;
        gravInc = 24-rate;//bullet gravity
        bull = t;
    }
    public int getX(){return x;}
    public int getY(){return y;}
    public Texture getTexture(){return bull;}

    public void changeX(){x+=vx;}
    public void changeY(){y+=vy;}

    public void changeVY(){vy-=gravInc/80;}
}
