package com.amaz1n.adheroes2;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.Input.Keys;


public class AdGame extends ApplicationAdapter {
	SpriteBatch batch;

	//1024x800

	Sprite spr1;
	Sprite spr2;
	player p1;
	player p2;
	Texture map;

	float INCG,MAXG;

	int LEFT,FORWARD,RIGHT;
	int IDLE,SHOOT,MELEE,WALK,JUMP;

	int frame;

	@Override
	public void create () {
		INCG = 0.25f;MAXG = -6.25f;//increment 0.25 is 1/25th of maximum 6.25

		LEFT = 0;FORWARD = 1;RIGHT = 2;
		IDLE = 0;WALK = 1;//SHOOT = 1;MELEE = 2;  ;JUMP = 10;
		batch = new SpriteBatch();
		Texture[][] slimeFrames = charFrames("slime1");
		p1 = new player("Slime",200,4,4,slimeFrames);//create player 1
		//p1.setCurrentFrame(RIGHT,WALK);
		spr1 = new Sprite(p1.getCurrentFrame());
		spr1.setPosition(p1.getX(),p1.getY());
		spr1.setScale(0.75f);//reduce size

		Texture[][] binFrames = charFrames("bin1");
		p2 = new player("Recycle Bin",696,8,8,binFrames);//equal distance
		//p2.setCurrentFrame(LEFT,WALK);
		spr2 = new Sprite(p2.getCurrentFrame());
		spr2.setPosition(p2.getX(),p2.getY());
		spr2.setScale(0.75f);

		map = new Texture("map_slimeFields.png");
	}

	public Texture[][] charFrames(String s){//load frames for each character
		Texture l0 = new Texture(s+"_IL.png");
		//Texture l1;
		//Texture l2;
		Texture l3 = new Texture(s+"_WL_1.png");
		Texture l4 = new Texture(s+"_WL_2.png");
		Texture l5 = new Texture(s+"_WL_3.png");
		Texture l6 = new Texture(s+"_WL_4.png");
		Texture l7 = new Texture(s+"_WL_5.png");
		Texture l8 = new Texture(s+"_WL_6.png");
		Texture[] lFrames = new Texture[]{l0,l3,l4,l5,l6,l7,l8};
		Texture f0 = new Texture(s+"_IF.png");////Only one frame
		Texture[] fFrames = new Texture[]{f0};///////////////front-facing
		Texture r0 = new Texture(s+"_IR.png");
		//Texture r1;
		//Texture r2;
		Texture r3 = new Texture(s+"_WR_1.png");
		Texture r4 = new Texture(s+"_WR_2.png");
		Texture r5 = new Texture(s+"_WR_3.png");
		Texture r6 = new Texture(s+"_WR_4.png");
		Texture r7 = new Texture(s+"_WR_5.png");
		Texture r8 = new Texture(s+"_WR_6.png");
		Texture[] rFrames = new Texture[]{r0,r3,r4,r5,r6,r7,r8};

		return new Texture[][]{lFrames,fFrames,rFrames};//return 2D array
	}

	public void moveLimits(player p){//falling, borders, ground, etc.
		//Vertical
		if(p.getY()<=100){//on or below ground
			p.setY(100);//confirm ground level ************add static variable for ground levels
			p.setFalling(false);//set falling to false
		}
		else{//not on the ground
			p.setFalling(true);//falling is true
		}

		if(!p.getFalling()){//if falling is false
			p.setVY(0);//stop velocity
		}
		else{//if falling is true
			if(p.getVY()>=MAXG){//travelling up or not at full gravity
				p.changeVY(-INCG);//subtract an increment
			}
			else{//reached or surpassed max gravity
				p.setVY(MAXG);//confirm max gravity
			}
		}
		//Horizontal
		if(p.getX()<=-25){//to account for differing texture borders,
			p.setX(-25);//some sprites may clip into the walls
		}
		if(p.getX()>=920){//1024-0.75(128)-8
			p.setX(920);
		}
		p.changeX(p.getVX());//move player
		p.changeY(p.getVY());
	}

	public void slimebounce(player p){////////////////////////////////////TEMPORARY TEST METHOD/////Success
		if(p.getY()<=100){
			p.setVY(10);
			p.changeX(p.getVX());
			p.changeY(p.getVY());
		}
	}
	public void binwalk(player p){///////////////////////////////////////TEMPORARY TEST METHOD
		if(p.getY()<=100){
			if(Gdx.input.isKeyPressed(Keys.LEFT) || Gdx.input.isKeyPressed(Keys.A)) {
				frame++;
				p.setVX(-2);
				p.setCurrentFrame(LEFT,WALK+frame/6 %6);
				p.changeX(p.getVX());
				p.changeY(p.getVY());
			}
			if(Gdx.input.isKeyPressed(Keys.LEFT) || Gdx.input.isKeyPressed(Keys.D)) {
				frame++;
				p.setVX(2);
				p.setCurrentFrame(RIGHT,WALK+frame/6 %6);
				p.changeX(p.getVX());
				p.changeY(p.getVY());
			}
		}
	}

	@Override
	public void render () {
		Gdx.gl.glClearColor(1, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		batch.begin();
		batch.draw(map,0,0);

		spr1.setTexture(p1.getCurrentFrame());
		spr1.draw(batch);
		moveLimits(p1);
		slimebounce(p1);/////////////////////////TEMPORARY
		spr1.setPosition(p1.getX(),p1.getY());

		spr2.setTexture(p2.getCurrentFrame());
		spr2.draw(batch);
		moveLimits(p2);
		binwalk(p2);/////////////////////////////TEMPORARY
		spr2.setPosition(p2.getX(),p2.getY());

		batch.end();
	}

	@Override
	public void dispose () {
		batch.dispose();
	}
}


/*
slime:         FR 4, DMG 4
recycle bin:   FR 8, DMG 8
fast food man: FR12, DMG12
witch cat:     FR16, DMG16
dumbbell rack: FR20, DMG20
robot:         FR24, DMG24
*/


